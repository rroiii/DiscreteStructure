def QuantifiersExample_2() :
    for x in range(-100, 100):
        if (x - 2 == 0):
            return True
    return False