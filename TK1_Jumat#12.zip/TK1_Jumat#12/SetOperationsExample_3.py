#A = {x | x^2 + x -6 = 0}
#B = {2, -3}

A=set ([x for x in range (-50,50) if x**2+x-6==0])
B=set ([2,-3])
A==B





