def implies(p,q):
    if p>=0 and q>=0:
        return p*q>=0
    else:
        return True

