for i1 in range(0,3):
    for i2 in range(0,3):
        for i3 in range (0, 3):
            print ("%d %d %d" (i1,i2,i3))

