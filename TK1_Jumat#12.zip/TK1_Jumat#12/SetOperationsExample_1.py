#S = {x | x = 2n; 0 <= n <= 19}

S = [2*x for x in range(19)]






