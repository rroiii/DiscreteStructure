for p in (True, False):
    for q in (True, False):
        print ("%10s %10s %10s" % (p, q, p and q))
